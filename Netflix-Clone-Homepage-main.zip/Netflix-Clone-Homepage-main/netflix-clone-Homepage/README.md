# netflix-clone-shapeai-bootcamp

This repo is part of the YouTube Bootcamp. 
[Here's the bootcamp](https://www.youtube.com/watch?v=Gy3gd2pB1Xc)
